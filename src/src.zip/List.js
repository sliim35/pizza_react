import React, { Component } from 'react'

class List extends Component {

  roleRus(role) {
    switch (role) {

      case 'cook':
        return 'Повар'
        break

      case 'driver':
        return 'Водитель'
        break

      case 'waiter':
        return 'Официант'
        break

    default:
      return 'Не указано'
      break
  }
}

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <table className="table table-hover">
              <thead className="thead-color">
                <tr>
                  <th>ФИО</th>
                  <th>Должность</th>
                  <th>Телефон</th>
                  <th>Дата рождения</th>
                </tr>
              </thead>
              <tbody>
                {this.props.employees.map((emp) => {
                  return(
                    <tr key={emp.id}>
                      <td>{emp.name}</td>
                      <td>{this.roleRus(emp.role)}</td>
                      <td>{emp.phone}</td>
                      <td>{emp.birthday}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }

}

export default List
